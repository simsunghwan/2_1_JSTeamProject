페이지 구성

Header / Main / Footer 컴포넌트로 구성한다.

<header-element> 
<main-element>
<footer-element> 

라우터




