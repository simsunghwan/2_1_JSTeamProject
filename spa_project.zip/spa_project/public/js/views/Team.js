export default class Team {
  constructor() {
    document.title = 'Team';
  }

  eventFunction() {}

  async getHtml() {
    return `
    <div class='container'>
      <h1>조원 소개 페이지</h1>
    </div>
    `
  }
}