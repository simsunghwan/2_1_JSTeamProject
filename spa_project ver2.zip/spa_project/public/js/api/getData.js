export const getCategoryData = async () => {
  const resCategory = await fetch("/category");
  const dataCategory = await resCategory.json();
  return dataCategory;
};

export const getProductData = async () => {
  const resProduct = await fetch("/product");
  const dataProduct = await resProduct.json();
  return dataProduct;
};

export const getEventData = async () => {
  const resEvent = await fetch("/event");
  const dataEvent = await resEvent.json();
  return dataEvent;
};

export const getUserData = async () => {
  const resUser = await fetch("/user");
  const dataUser = await resUser.json();
  return dataUser;
};
