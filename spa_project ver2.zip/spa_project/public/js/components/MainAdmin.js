  import AdminHome from '../views/admin/AdminHome.js';
  import Products from '../views/Products.js';
  import ProductDetail from '../views/ProductDetail.js';
  import AdminCategories from '../views/admin/AdminCategories.js';
  import AddCategory from '../views/admin/AddCategory.js';
  import EditCategory from '../views/admin/EditCategory.js';
  import AdminProducts from '../views/admin/AdminProducts.js';
  import AddProduct from '../views/admin/AddProduct.js';
  import EditProduct from '../views/admin/EditProduct.js';


  class MainAdmin extends HTMLElement {
    constructor() {
      super();
      this.viewInstances = [];
    }

    connectedCallback() {
      console.log('connectedCallback');
    }

    disconnectedCallback() {
      console.log('disconnectedCallback');
    }

    static get observedAttributes() {
      console.log('observedAttributes');
      return ['data-render'];
    }

    attributeChangedCallback(attrName, prevValue, curValue) {
      console.log('attributeChangedCallback');
      console.log(`속성명: ${attrName}, 이전 속성값: ${prevValue}, 현재 속성값: ${curValue}`);
      if (attrName === 'data-render' && prevValue !== curValue) {
        console.log('어드민 메인 렌더링!');
        this.render();
      } 
    }

    async render() {
      console.log('rendering...');

      const render = this.dataset.render;

      let firParam = '';
      let secParam = '';
  
      //
      const paramIndex = render.indexOf('/');
      if (paramIndex !== -1) {
        firParam = render.slice(0, paramIndex);
        secParam = render.slice(paramIndex + 1);
      } 
      else {
        firParam = render;
      }
  
      // 뷰 인스턴스 배열에 파라미터 값과 뷰의 속성 값이 일치하는 뷰를 찾기
      let view = this.viewInstances.find(view => view['name'] === firParam);

      if (!view) {
      switch (firParam) {
        case 'admin_home':
          view = AdminHome.getInstance();
          break;

        case 'products':
          view = Products.getInstance();
          break;

        case 'product_detail':
          view = ProductDetail.getInstance()
          break;    

        case 'admin_categories':
          view = AdminCategories.getInstance()
          break;

        case 'add_category':
          view = AddCategory.getInstance()
          break;

        case 'edit_category':
          view = EditCategory.getInstance()
          break;

        case 'admin_products':
          view = AdminProducts.getInstance()
          break;

        case 'add_product':
          view = AddProduct.getInstance()
          break;

        case 'edit_product':
          view = EditProduct.getInstance()
          break; 

        }

      // 뷰 인스턴스 배열에 생성한 뷰 인스턴스를 추가
      this.viewInstances.push(view);
      }

    // 뷰를 구분하는 동시에 재사용할 수 있도록 속성을 지정
    view['name'] = firParam;

    // 디버깅
    console.log(this.viewInstances);

    // 해당 뷰의 HTML 을 불러옴
    this.innerHTML = await view.getHTML(secParam);
    // HTML이 DOM에 추가되면 이벤트를 바인딩함
    view.bindEvents(secParam);
    }
  }

  customElements.define('main-admin-element', MainAdmin);