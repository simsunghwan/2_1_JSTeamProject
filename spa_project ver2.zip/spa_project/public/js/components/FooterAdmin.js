class FooterAdmin extends HTMLElement {
  constructor() {
    super();
  }


  render() {
    this.innerHTML = `
      <br><br><br>
      <hr>    
      <p class="text-center">&COPY; 6조 자바스크립트 - 어드민 계정</p>
    `
  }

}

customElements.define('footer-admin-element', FooterAdmin);