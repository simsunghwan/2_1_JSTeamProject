import '../components/Main.js';
import '../components/Header.js';
import '../components/Footer.js';

export default class Page {
  constructor() {
    this.firstView = 'home';
  }

  getHtml() {
    return `
      <header-element data-render=""></header-element>
      <main-element data-render="${this.firstView}"></main-element>
      <footer-element></footer-element>
    `
  }
}