import { getCategoryData, getProductData } from '../api/getData.js';

export default class Products {
  constructor() {
    document.title = 'Products';
  }

  // Product 클래스의 뷰 인스턴스
  static instance = null;

  // Product 클래스의 뷰 인스턴스를 불러오는 클래스 메서드
  static getInstance() {
    // 뷰 인스턴스가 존재하지 않으면 생성, 존재하면 그 인스턴스를 그대로 반환
    if (!Products.instance) {
      Products.instance = new Products();
    }
    return Products.instance;
  }

  bindEvents() {
    return;
  }

  // HTML 불러오기
  async getHTML (subTitle) {
    this.dataCategory = await getCategoryData();
    this.dataProduct = await getProductData();

    // categoryRows 
    const categoryRows = this.dataCategory.map(category => {
      return `
        <li class="list-group-item"><a data-render="products/${category.slug}" data-link>${category.title}</a></li>
      `;
    }).join("");
    
    // productRows
    const productRows = this.dataProduct.map(product => {
      if (subTitle === '' || subTitle === product.category) {
        return `
          <div class="col-xs-12 col-md-4 p">
            <a class="pa" data-link>
              <img class="pimage" src="${product.image}" data-render="product_detail/${product.slug}" data-link>
            </a>
            <h3>${product.title}</h3>
            <h4>${product.price}원</h4> 
            <a class="vd" data-render="product_detail/${product.slug}" data-link>View Details</a>
          </div>
        `;
      }
    }).join("");

    return `
      <div class="container">
        <div class="row">
          <div class="col-xs-12 col-md-3">
            <h3>상품 카테고리</h3>
            <ul class="list-group">
              <li class="list-group-item"><a data-render="products" data-link>All products</a></li>
              ${categoryRows}
            </ul>
          </div>
          <div class="col-xs-12 col-md-1"></div>
          <div class="col-xs-12 col-md-8">
            <div class="row products">
              ${productRows}
            </div> 
          </div>
        </div>
      </div>
    `;
  }
}
