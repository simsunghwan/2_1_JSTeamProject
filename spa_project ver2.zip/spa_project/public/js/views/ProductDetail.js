import { getCategoryData, getProductData } from '../api/getData.js';

  export default class ProductDetail{
    constructor() {
      document.title = 'ProductDetail';
      this.id = '';
      this.product = '';
      this.whoLoggedIn = '';
      this.userID = '';
    }

    static instance = null;

    // 클래스의 뷰 인스턴스를 불러오는 클래스 메서드
    static getInstance() {
      // 뷰 인스턴스가 존재하지 않으면 생성, 존재하면 그 인스턴스를 그대로 반환
      if (!ProductDetail.instance) {
        ProductDetail.instance = new ProductDetail();
      }
      return ProductDetail.instance;
    }

    bindEvents() {
      this.addCart();
    }

    async getHTML(secParam) {
      const dataCategory = await getCategoryData(); 
      const dataProduct = await getProductData(); 

      const categoryRows = dataCategory.map(category => {
        return `
        <li class="list-group-item"><a data-render="products/${category.slug}" data-link>${category.title}</a></li>
        `;
      }).join("");

      const matchingProduct = dataProduct.find(product => {
        if (product.slug === secParam) {
          this.id = product.id;
          this.product = secParam;
          return true;
        }
      });

      let addCartTemplete;

      const whoLoggedIn = this.whoLoggedIn = localStorage.getItem('userType');
      const userID = this.userID = localStorage.getItem('userID');

      // 게스트 유저
      if (whoLoggedIn === null) {
        addCartTemplete = `<p><a id='btn-cart' data-render="login" data-link>장바구니에 담기</a></p>`
      }
    
      else if (whoLoggedIn === 'user') {
        addCartTemplete = `<p><a id='btn-cart' data-render="product_detail/${this.product}" data-link>Add to Cart</a></p>`
      }
      return `

      <div class="container">
        <div class="row">
        <div class="col-xs-12 col-md-3">
            <h3>상품 카테고리</h3>
            <ul class="list-group">
              <li class="list-group-item"><a data-render="products" data-link>All products</a></li>
                ${categoryRows}
            </ul>
          </div>
          <div class="col-xs-12 col-md-1"></div>
          <div class="col-xs-12 col-md-8">

          <div class="row">

          <h1 class="page-header">${matchingProduct.title}</h1>

          <div class="col-xs-12 col-md-5">
            <img class="spi" src="${matchingProduct.image}" alt="">
            <br>
          </div>  
          <div class="col-xs-12 col-md-7">
            <br>
            <p>${matchingProduct.desc}</p>
            <br>
            <p>${matchingProduct.price}원</p>
            <br>  
            ${addCartTemplete}
            
          </div>
          
        </div>
        </div>
        </div>
        </div>

        `;
    } 

    addCart() {
      const addCartBtn = document.getElementById('btn-cart');
      const self = this;

      addCartBtn.addEventListener('click', async () => {
        // 일반 유저이면
        if (localStorage.getItem('userType') === 'user') {
          let cartItems = JSON.parse(localStorage.getItem(`cart/${localStorage.getItem('userID')}`));
          // 카트에 동일한 상품 있는지 확인
          const itemIndex = cartItems.findIndex(element => element.title === self.product);
          // 존재하면
          if (itemIndex !== -1) {
            // 5개 미만이면
            if (parseInt(cartItems[itemIndex].qty) < 5) {
              alert('상품의 개수를 추가했습니다.');
              cartItems[itemIndex].qty = parseInt(cartItems[itemIndex].qty) + 1;
            }
            else {
              alert('구매 가능 개수(5)를 초과했습니다!');
            }
          }
          // 없으면
          else {
            const dataProduct = await getProductData(); 
            const product = dataProduct.find(p => p.slug === self.product);
            cartItems.push({
              id: self.id,
              title: self.product,
              qty: 1,
              price: product.price
            });
            alert('상품을 장바구니에 담았습니다.');
          }

          localStorage.setItem(`cart/${self.userID}`, JSON.stringify(cartItems));
          document.getElementById('cart-item').innerHTML = `My Cart(${cartItems.length})`;
        }
        else if (localStorage.getItem('userType') === 'admin') {
          return;
        }
        // 게스트이면
        else if (localStorage.getItem('userType') === null) {
          alert('로그인이 필요합니다!');
        }
      });
    }
  }