import { getUserData } from '../api/getData.js';

export default class Login {
  constructor() {
    document.title = 'Login';
  }

  // 클래스의 뷰 인스턴스
  static instance = null;

  // 클래스의 뷰 인스턴스를 불러오는 클래스 메서드
  static getInstance() {
    // 뷰 인스턴스가 존재하지 않으면 생성, 존재하면 그 인스턴스를 그대로 반환
    if (!Login.instance) {
      Login.instance = new Login();
    }
    return Login.instance;
  }

  bindEvents() {
    // 폼 제출 이벤트 등록
    const form = document.getElementById('login-form');
    form.addEventListener('submit', this.submitForm.bind(this));
  }

  async submitForm(e) {

    e.preventDefault(); // 기본 제출 동작 방지

    const formData = new FormData(e.target);

    // 유저 목록을 불러오기
    const dataUser = await getUserData();

    // 유저 목록에서 입력한 아이디와 비밀번호 일치하는 유저가 존재하는지 확인
    // 비밀번호 평문 비교는 보안에 매우 취약
    const loggedInUser = dataUser.find((user) =>
        user.userid === formData.get('userid') &&
        user.password === formData.get('password')
    );

    // 만약 유저 목록과 일치하는 유저가 있으면
    if (loggedInUser) {
      // 로그인 성공, loginSuccess 메서드 실행
      this.loginSuccess(loggedInUser);
    } else {
      // 로그인 실패, loginFailure 메서드 실행
      this.loginFailure();
    }
  }

  // 로그인이 성공했을 시 실행되는 메서드
  loginSuccess(user) {
    // 다시 렌더링할 엘리먼트를 선택
    const mainElement = document.querySelector('main-element');
    const headerElement = document.querySelector('header-element');

    // 만약 로그인한 유저가 관리자인 경우
    if (user.isAdmin === 1) {
      // 로컬스토리지의 userType 을 관리자로 지정
      localStorage.setItem('userType', 'admin');
    } 
    // 만약 로그인한 유저가 일반 사용자인 경우
    else {
    // 로컬 스토리지의 userType 을 일반 사용자로 지정
      localStorage.setItem('userType', 'user');

      // 일반 사용자는 장바구니를 생성
      // 만약 유저의 아이디로 구성된 장바구니가 존재하지 않을 경우
      if (localStorage.getItem(`cart/${user.userid}`) === null) {
        // 유저의 아이디로 구성된 장바구니 배열을 로컬 스토리지에 추가
        localStorage.setItem(`cart/${user.userid}`, JSON.stringify([]));
      }
    }

    // 로컬 스토리지에 유저 아이디 추가
    localStorage.setItem('userID', user.userid);
    // 로컬 스토리지에 유저 이름 추가
    localStorage.setItem('username', user.username);

    // 헤더와 메인의 render 속성을 지정
    headerElement.setAttribute('data-render', '');
    mainElement.setAttribute('data-render', 'home');
  }


    // 로그인이 실패했을 시 실행되는 메서드
  loginFailure() {
    // 로그인 실패 처리
    alert('올바른 정보를 입력해주세요!');
  }


  async getHTML() {
    return `
      <div class='container'>
        <h1>Login</h1>
        <form id="login-form" method="post">
          <div class="form-group">
            <label>UserID</label>
            <input type="text" name="userid" class="form-control" placeholder="UserID">
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" class="form-control" placeholder="Password">
          </div>
          <button class="btn btn-default" type="submit">Submit</button>
        </form>
      </div>
    `;
  }
}
