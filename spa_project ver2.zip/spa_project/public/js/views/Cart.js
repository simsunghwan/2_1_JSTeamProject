import { getProductData } from '../api/getData.js';

export default class Cart {
  constructor() {
    document.title = 'Cart';

    // 로그인한 일반 사용자의 userID
    this.userID = '';
    // 로그인한 일반 사용자의 장바구니 상품 목록
    this.cartItems = '';
  }

  static instance = null;

  static getInstance() {
    if (!Cart.instance) {
      Cart.instance = new Cart();
    }
    return Cart.instance;
  }

  bindEvents() {
    const $btn_update_quantity = document.querySelectorAll('.btn_update_quantity');
    const self = this;
  
    $btn_update_quantity.forEach((element, index) => {
      element.addEventListener('click', () => {
        self.updateQuantity(index);
      });
    });
  }

  async getHTML() {
    // 상품
    const dataProduct = await getProductData();

    const userID = this.userID = localStorage.getItem('userID');
    const cartItems = this.cartItems = JSON.parse(localStorage.getItem(`cart/${userID}`));

    // 장바구니 템플릿
    let cartTemplate = '';

    // 내가 장바구니에 추가한 상품의 목록
    const myItems = cartItems.map(item => {

      // Product -> { slug: 'potato-chip', ... }
      // Cart -> { title: 'potato-chip', ... }

      // 상품의 정보와 장바구니에 담은 상품의 정보가 일치하는 상품을 찾기
      const matchingProduct = dataProduct.find((product) => 
        product.slug === item.title);

      // 만약 정보가 일치하는 상품이 존재하면
      if (matchingProduct) {
        return `
          <tr>
            <td><img src="${matchingProduct.image}" width=100 height=100 ></td>
            <td>${matchingProduct.title}</td>
            <td>${matchingProduct.price}</td>
            <td class="item-qty">${item.qty}</td>
            <td>
              <input class="inp_item_quantity" type="number" name="qty" min="0" max="5" step="1" value="${item.qty}">
              <button class="btn_update_quantity">change</button>
            </td>
            <td class="item-total-price">${matchingProduct.price * parseInt(item.qty)}원</td>
          </tr>
        `;
      }
    })
    .join('');


    // 만약 장바구니에 아무것도 담겨있지 않다면
    if (!this.cartItems.length) {
      cartTemplate = `<h3 class="text-center">장바구니가 비어있습니다.</h3>`;
    } 
    // 만약 장바구니에 무엇이라도 담겨있다면
    else {
      cartTemplate = `
        <table class="table table-striped">
          <tr>
            <th>Product Image</th>
            <th>Product Title</th>
            <th>Price</th>
            <th>Qty</th>
            <th></th>
            <th>TOTAL</th>
          </tr>
          ${myItems}
        </table>
      `;
    }

    // HTML 내용
    return `
      <div class='container'>
        <h1>장바구니 페이지</h1>
        ${cartTemplate}
      </div>
    `;
  }

  updateQuantity(index) {
    const inp_item_quantity = document.querySelectorAll('.inp_item_quantity');
    const self = this;
    if (parseInt(inp_item_quantity[index].value) === 0) {
      // 로컬 스토리지의 장바구니에서 제거
      self.cartItems.splice(index, 1);
      localStorage.setItem(`cart/${self.userID}`, JSON.stringify(self.cartItems));
      document.querySelector('header-element').setAttribute('data-render', '');
      const $table = document.querySelector('.table');
      const $tableRow = $table.rows[index + 1];
      $tableRow.parentNode.removeChild($tableRow);
    } 
    else {
      self.cartItems[index].qty = parseInt(inp_item_quantity[index].value);
      localStorage.setItem(`cart/${self.userID}`, JSON.stringify(self.cartItems));
      document.querySelectorAll('.item-qty')[index].innerText = self.cartItems[index].qty;
      document.querySelectorAll('.item-total-price')[index].innerText = `${self.cartItems[index].qty * self.cartItems[index].price}원`;
    }
  }
}
