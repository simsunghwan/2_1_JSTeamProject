import { getCategoryData, getEventData } from '../api/getData.js';

export default class Events {
  constructor() {
    document.title = 'Events';

  }

  static instance = null;

  // 클래스의 뷰 인스턴스를 불러오는 클래스 메서드
  static getInstance() {
    // 뷰 인스턴스가 존재하지 않으면 생성, 존재하면 그 인스턴스를 그대로 반환
    if (!Events.instance) {
      Events.instance = new Events();
    }
    return Events.instance;
  }

  bindEvents() {
    return;
  }

  async getHTML() {
    const dataCategory = await getCategoryData(); 
    const dataEvent = await getEventData(); 

    // 카테고리
    const categoryRows = dataCategory.map(category => {
      return `
          <li class="list-group-item"><a data-render="products/${category.slug}">${category.title}</a></li>
      `;
    }).join("");

    // 이벤트
    const eventRows = dataEvent.map(event => {
      return `
      <div>
        <a class="">
          <img class="" src="${event.image}" data-render="" style="width: 100%; height: 180px; background-color: rgba(255, 255, 128, .5); border: 3px solid black;">
        </a>
      </div>
      `
    });

    // HTML 내용
    return `
    <div class='container'>
    <div class="row">
      <div class="col-xs-12 col-md-3">
        <h3>상품 카테고리</h3>
        <ul class="list-group">
          <li class="list-group-item"><a data-render="products">All products</a></li>
            ${categoryRows}
        </ul>
      </div>
      <div class="col-xs-12 col-md-1"></div>
      <div class="col-xs-12 col-md-8">
      <h1>6월의 이벤트 혜택!</h1>
        <br>
        ${eventRows}
        <br>
      </div>
      </div>
      </div>
    `
  }
}