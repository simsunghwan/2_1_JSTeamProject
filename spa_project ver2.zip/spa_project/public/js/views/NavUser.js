export default class NavUser {
  constructor() {

  }

  bindEvents() {
    const logoutBtn = document.getElementById('btn-logout');
    logoutBtn.addEventListener('click', this.confirmLogout.bind(this));
  }
  

  getHTML() {
    let navTemplete;

    const loginUser = localStorage.getItem('userID');
    const loginUsername = localStorage.getItem('username');

    const whoLoggedIn = localStorage.getItem('userType');

      if(whoLoggedIn === 'admin') {
        // 어드민
        navTemplete = `
        <li><a class="nav__link" id="btn-logout" data-render="home">Hi! ${loginUsername} (로그아웃)</a></li>
        <li><a class="nav__link" href="/admin" data-render="" data-linq>Go to Admin Area</a></li>
        `
      }
      else {
        // 일반 유저
        let cartItemQty = JSON.parse(localStorage.getItem(`cart/${loginUser}`)).length;

        navTemplete = `
        <li><a class="nav__link" id="cart-item" data-render="cart">My Cart(${cartItemQty})</a></li>
        <li><a class="nav__link" id="btn-logout" data-render="home">Hi! ${loginUsername} (로그아웃)</a></li>
        `
      }

    return `
      <nav class="navbar navbar-inverse">
        <div class="container">
          <div class="navbar-header">
            <a class="navbar-brand nav__link" data-render="home">SPA ecommerce</a>
          </div>
          <div id="navbar" class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
            <li><a class="nav__link" data-render="products">상품</a></li>
              <li><a class="nav__link" data-render="events">진행 중인 이벤트</a></li>
              <li><a class="nav__link" data-render="board">게시판</a></li>
              <li><a class="nav__link" data-render="team">조원 소개</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
              ${navTemplete}
          </ul>
          </div>
        </div>
      </nav>
    `;
  }

  confirmLogout() {
    const checkLogout = confirm('로그아웃 하시겠습니까?');
    if (checkLogout) {
      localStorage.removeItem('userID');
      localStorage.removeItem('userType');
      localStorage.removeItem('username');
      document.querySelector('header-element').setAttribute('data-render', '');
    }
  }
  
}
