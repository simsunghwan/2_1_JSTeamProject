export default class NavGuest {
  constructor() {

  }

  getHTML() {
    return `
      <nav class="navbar navbar-inverse">
        <div class="container">
          <div class="navbar-header">
            <a class="navbar-brand nav__link" data-render="home">SPA ecommerce</a>
          </div>
          <div id="navbar" class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
              <li><a class="nav__link" data-render="products">상품</a></li>
              <li><a class="nav__link" data-render="events">진행 중인 이벤트</a></li>
              <li><a class="nav__link" data-render="board">게시판</a></li>
              <li><a class="nav__link" data-render="team">조원 소개</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
              <li><a class="nav__link" data-render="register">회원가입</a></li>
              <li><a class="nav__link" data-render="login">로그인</a></li>
          </ul>
          </div>
        </div>
      </nav>
    `;

  }

  bindEvents() {
    return;
  }

} 
