import { getCategoryData } from '../../api/getData.js';

export default class AdminHome {
  constructor() {
    document.title = 'AdminHome';
  }

  static instance = null;

  // 클래스의 뷰 인스턴스를 불러오는 클래스 메서드
  static getInstance() {
    // 뷰 인스턴스가 존재하지 않으면 생성, 존재하면 그 인스턴스를 그대로 반환
    if (!AdminHome.instance) {
      AdminHome.instance = new AdminHome();
    }
    return AdminHome.instance;
  }

  bindEvents() {
    return;
  }

  async getHTML() {
    const dataCategory = await getCategoryData(); 

    const categoryRows = dataCategory.map(category => {
      return `
          <li class="list-group-item"><a data-render="products/${category.slug}" data-link>${category.title}</a></li>
      `;
    }).join("");

    return `
    <div class='container'>
    <div class="row">
      <div class="col-xs-12 col-md-3">
        <h3>Categories</h3>
        <ul class="list-group">
          <li class="list-group-item"><a data-render="products" data-link>All products</a></li>
            ${categoryRows}
        </ul>
      </div>
      <div class="col-xs-12 col-md-1"></div>
      <div class="col-xs-12 col-md-8">
      <h1>Welcome!</h1>
      <h3>어드민 테스트 페이지입니다.</h3>
      <p>
        <br>
      </p>
      <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
      </p>

      </div>
      </div>
      </div>
    `
  }
}