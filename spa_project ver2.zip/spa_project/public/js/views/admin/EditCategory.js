import { getCategoryData, getProductData } from '../../api/getData.js';

export default class EditCategory {
  constructor() {
      document.title = 'EditCategory';
      this.curTitle = '';
  }

  static instance = null;

  // 클래스의 뷰 인스턴스를 불러오는 클래스 메서드
  static getInstance() {
    // 뷰 인스턴스가 존재하지 않으면 생성, 존재하면 그 인스턴스를 그대로 반환
    if (!EditCategory.instance) {
      EditCategory.instance = new EditCategory();
    }
    return EditCategory.instance;
  }

    async getHTML(subTitle) {
      const dataCategory = await getCategoryData(); 
      const self = this;

      let title = "";
      
      // 번호랑 일치하는 카테고리
      dataCategory.forEach(category => {
        if (category.id === parseInt(subTitle)) {
          // 카테고리의 타이틀을 설정  
          title = self.curTitle = category.title;
        }
      });

        return `
        <div class="container">
        <h2 class="page-title">Edit a category</h2>
        <a class="btn btn-primary" data-render="admin_categories" data-link>Back to all categories</a>
  
        <br><br><br>
  
        <form id="edit-category-form" method="post">

          <div class="form-group">
            <label for="">Title</label>
            <input type="text" class="form-control" name="title" value= "${title}" placeholder="Title">
          </div>
  
          <button class="btn btn-default" data-render="admin_categories">Submit</button>
        </form>
        </div>
            `;
    }

  bindEvents(subTitle) {
    const form = document.getElementById('edit-category-form');
    const self = this;
    form.addEventListener('submit', async (e) => {
      e.preventDefault(); // 기본 제출 동작 방지

      const dataProduct = await getProductData(); 
      const formData = new FormData(form);

      const categoryId = subTitle;

      await fetch('/category/' + categoryId, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify( {
          title: formData.get('title'),
          slug: formData.get('title').toLowerCase()
        })
      });

      // 카테고리의 타이틀 변경 시 자동으로 프로덕트의 카테고리도 동일하게 변경해야 함!!

      // 수정하기 전의 카테고리 타이틀과 프로덕트의 카테고리가 같은 것의 id가 모인 배열
      // [1, undefined, 3, undefined, 5, 6, 7, undefined ...] 
      const prodCategoryId = dataProduct.map(product => {
        if (product.category === self.curTitle) {
          return product.id;
        }
      });

      // 위의 배열에서 바꾸려는 대상의 id만으로 구성된 배열을 구성한다.
      // [1, 3, 5, 6, 7, ...]
      const filteredId = prodCategoryId.filter(id => id !== undefined);

      // id를 대입하여 수정한 후의 카테고리 타이틀을 PATCH를 통해 부분 수정한다.
      filteredId.forEach(id => {
        fetch('/product/' + id, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify( {
            category: formData.get('title')
          })
        });
      });

      // 뷰를 바꿀 뿐 HTML은 그대로 이기 때문에 수정된 결과를 확인하기 위해 다시 불러와야 함.
      const mainAdminElement = document.querySelector('main-admin-element');
      // 먼저 이전에 생성된 뷰를 찾아옴
      const adminCategoriesView = mainAdminElement.viewInstances.find(view => view['name'] === 'admin_categories');
      // 만약 뷰가 있다면
      if (adminCategoriesView) {
        // 새롭게 수정된 데이터가 포함된 HTML을 불러옴
        const html = await adminCategoriesView.getHTML();
        mainAdminElement.innerHTML = html;
      }
    });
  }
}
