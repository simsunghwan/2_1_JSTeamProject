  import { getCategoryData, getProductData } from '../../api/getData.js';

  export default class AdminCategories {
    constructor() {
      document.title = 'Categories';
      this.categoryId = 0;
    }

    static instance = null;

    // 클래스의 뷰 인스턴스를 불러오는 클래스 메서드
    static getInstance() {
      // 뷰 인스턴스가 존재하지 않으면 생성, 존재하면 그 인스턴스를 그대로 반환
      if (!AdminCategories.instance) {
        AdminCategories.instance = new AdminCategories();
      }
      return AdminCategories.instance;
    }

    async getHTML() {
      // 카테고리 데이터 불러옴
      const dataCategory = await getCategoryData(); 

      // 데이터 표시
      const tableRows = dataCategory.map(category => {
        return `
          <tr>
              <td>${category.title}</td>
              <td><a data-render="edit_category/${category.id}" data-link>Edit</a></td>
              <td><a class="btn-delete" data-render="admin_categories/delete=${category.id}" data-link>Delete</a></td>
          </tr>
        `;
        }).join("");

        return `
          <div class="container">
            <h2 class="page-title">Categories 카테고리</h2>
            <a class="btn btn-primary" id="btn" data-render="add_category" data-link>Add a new category</a>
            
            <br><br><br>

            <table class="table table-striped">
              <thead>
                <tr>
                  <th>Category</th>
                  <th>Edit</th>
                  <th>Delete</th>
                </tr>
              </thead>
              <tbody>
                ${tableRows}
              </tbody>
            </table>
          </div>
        `;
    }

    bindEvents() {
      const deleteBtn = document.querySelectorAll('.btn-delete');

      // 모든 버튼 마다 이벤트를 추가
      deleteBtn.forEach((element) => {
        element.addEventListener("click", async () => {
            const categoryId = element.dataset.render.replace("admin_categories/delete=", "");
            // 이 카테고리에 해당하는 상품이 존재하면 삭제 불가 구현..

            // 상품 정보 불러옴
            const dataCategory = await getCategoryData(); 
            const dataProduct = await getProductData();
            // 먼저 카테고리 아이디가 일치하는 카테고리만 가져옴
            const category = dataCategory.find(category => parseInt(category.id) === parseInt(categoryId));
            // 그 카테고리를 가지고 있는 제품을 가져옴
            const product = dataProduct.find(product => product.category === category.slug);

            // 만약 해당 카테고리를 가진 제품이 존재하면
            if (product) {
              alert('해당 카테고리를 가진 상품이 존재합니다.');
            }
            // 해당 카테고리를 가진 제품이 없으면
            else {
              await fetch('/category/' + categoryId, {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json'}
              }); 
            }
            document.querySelector('main-admin-element').setAttribute('data-render', 'admin_categories');
        });
      });
    }
  }
