import { getProductData } from '../../api/getData.js';

export default class AdminProducts {
  constructor() {
    document.title = 'AdminProducts';
  }

  static instance = null;

  // 클래스의 뷰 인스턴스를 불러오는 클래스 메서드
  static getInstance() {
    // 뷰 인스턴스가 존재하지 않으면 생성, 존재하면 그 인스턴스를 그대로 반환
    if (!AdminProducts.instance) {
      AdminProducts.instance = new AdminProducts();
    }
    return AdminProducts.instance;
  }

  async getHTML() {

    // 제품 정보 불러오기
    const dataProduct = await getProductData(); 

    // 테이블 양식
    let tableRows = '';

    // 
    if (dataProduct.length === 0) {
      return `
      <div class="container">
        <h2 class="product-title">Products 상품</h2>
        <a data-render="add_product" class="btn btn-primary" id="btn" data-link>Add a new product</a>
        <br><br><br>
        <h3 class="text-center">There are no products.</h3>
      <div>
      `
    }
    else {
      tableRows = dataProduct.map(product => {
        if (product.image === '') {
            return `
                <tr>
                <td>${product.title}</td>
                <td>₩${product.price}</td>
                <td>${product.category}</td>
                <td><img src="https://upload.wikimedia.org/wikipedia/commons/1/14/No_Image_Available.jpg" width=100 alt=""></td>
                <td><a data-render="edit_product/${product.id}" data-link>Edit</a></td>
                <td><a class="btn-delete" data-render="admin_products/" data-link>Delete</a></td>
                </tr>
            `;
        } else {
            return `
                <tr>
                    <td>${product.title}</td>
                    <td>₩${product.price}</td>
                    <td>${product.category}</td>
                    <td><img src="${product.image}" width=100 height=100 alt=""></td> 
                    <td><a data-render="edit_product/${product.id}" data-link>Edit</a></td>
                    <td><a class="btn-delete" data-render="admin_products/delete=${product.id}" data-link>Delete</a></td>
                </tr>
            `;
        }
    }).join("");
}
  
      return `
        <div class="container">
          <h2 class="product-title">Products 상품</h2>
          <a data-render="add_product" class="btn btn-primary" id="btn" data-link>Add a new product</a>
          
          <br><br><br>

          <table class="table table-striped">
              <thead>
                  <tr>
                      <th>Product</th>
                      <th>Price</th>
                      <th>Category</th>
                      <th>Product image</th>
                      <th>Edit</th>
                      <th>Delete</th>
                  </tr>
              </thead>
              <tbody>
                  ${tableRows}
              </tbody>
          </table>
        </div>
          `;
  }

    bindEvents() {
      const deleteBtn = document.querySelectorAll('.btn-delete');
      deleteBtn.forEach((element) => {
        element.addEventListener("click", async () => {
          const productId = element.dataset.render.replace("admin_products/delete=", "");
          // 상품을 지울 때, 만약 장바구니에 해당 상품이 있으면 장바구니에서도 지워야 함.
          // 로컬 스토리지의 모든 키를 불러옴.
          const loccalStorageKeys = Object.keys(localStorage);
          
          loccalStorageKeys.forEach(cart => {
            // startsWith() 로 로컬 스토리지의 cart/ 로 시작하는 일반 사용자의 장바구니만 선택
            if (cart.startsWith('cart/')) {
              // 일반 사용자의 장바구니 배열
              const cartItems = JSON.parse(localStorage.getItem(cart));
              // 삭제하려는 상품과 같은 id를 가진 상품을 제외한 배열을 생성
              const updatedCartItems = cartItems.filter(item => parseInt(item.id) !== parseInt(productId));
              // 업데이트된 장바구니 배열을 다시 저장
              localStorage.setItem(cart, JSON.stringify(updatedCartItems));
            }
          });
          await fetch('/product/' + productId, {
            method: 'DELETE',
                headers: { 'Content-Type': 'application/json' }
              });
        });
      });
    }
}
