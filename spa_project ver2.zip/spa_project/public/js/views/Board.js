export default class Board {
  constructor() {
    document.title = 'Board';
  }

  static instance = null;

  // 클래스의 뷰 인스턴스를 불러오는 클래스 메서드
  static getInstance() {
    // 뷰 인스턴스가 존재하지 않으면 생성, 존재하면 그 인스턴스를 그대로 반환
    if (!Board.instance) {
      Board.instance = new Board();
    }
    return Board.instance;
  }

  eventFunction() {}

  async getHtml() {

    return `
    <div class='container'>
      <h1>게시판 페이지</h1>
    </div>
    `
  }
}