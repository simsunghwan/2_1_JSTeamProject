
    import UserHome from "./views/user/Home.js"
    import Products from "./views/user/Products.js"
    import ProductsOrdered from "./views/user/ProductsOrdered.js"
    import ProductDetail from "./views/user/ProductDetail.js"
    import AdminHome from "./views/admin/Home.js";
    import About from "./views/About.js";
    import PostView from "./views/PostView.js";
    import Contact from "./views/Contact.js";
    import AdminPages from "./views/admin/Pages.js";
    import AdminAddPage from "./views/admin/AddPage.js";
    import AdminEditPage from "./views/admin/EditPage.js";
    import AdminCategories from "./views/admin/Categories.js";
    import AdminAddCategory from "./views/admin/AddCategory.js";
    import AdminEditCategory from "./views/admin/EditCategory.js";
    import AdminProducts from "./views/admin/Products.js";
    import AdminAddProduct from "./views/admin/AddProduct.js";
    import AdminEditProduct from "./views/admin/EditProduct.js";

    const navigateTo = url => {
        history.pushState(null, null, url);
        router();
    };

    const router = async () => {
        const routes = [
            { path: "/", view: UserHome },
            { path: "/products", view: Products },
            { path: "/products/:id", view: ProductsOrdered },
            { path: "/products/:category/:id", view: ProductDetail },
            { path: "/admin", view: AdminHome },
            { path: "/about", view: About },
            { path: "/posts/:id", view: PostView },
            { path: "/contact", view: Contact },
            { path: "/admin/pages", view: AdminPages },
            { path: "/admin/pages/add-page", view: AdminAddPage },
            { path: "/admin/pages/edit-page/:id", view: AdminEditPage },
            { path: "/admin/categories", view: AdminCategories },
            { path: "/admin/categories/add-category", view: AdminAddCategory },
            { path: "/admin/categories/edit-category/:id", view: AdminEditCategory },
            { path: "/admin/products", view: AdminProducts },
            { path: "/admin/products/add-product", view: AdminAddProduct },
            { path: "/admin/products/edit-product/:id", view: AdminEditProduct }
        ];

        // "/products/:category/:id" 인자 두개 받는 경우 view 매칭이 안되고 있음

        const pageMatches = routes.map((route) => {
            const regex = new RegExp(`^${route.path.replace(/:\w+/g, '\\w+')}$`);

            return {
                route,
                isMatch: regex.test(location.pathname)
            };
        });

        let match = pageMatches.find((pageMatch) => pageMatch.isMatch);
                
                if (!match) {
                    match = {
                        route: routes[0],
                        isMatch: true,
                    };
                }
                console.log(match.route);
                const view = new match.route.view();	

        document.querySelector("#app").innerHTML = await view.getHtml();
        view.pageFunction();
    };

    window.addEventListener("popstate", router);

    document.addEventListener("DOMContentLoaded", () => {
        document.body.addEventListener("click", e => {
            if (e.target.className === "btn btn-default") {
                
                navigateTo(e.target.dataset.href);
                return;
            } 
            if (e.target.className === "confirmDeletion") {
                e.preventDefault();
                navigateTo(location.pathname);
                return;
            }
            if (e.target.matches("[data-link]")) {
                e.preventDefault();
                navigateTo(e.target.href);
                return;
            }
        });

        router();
    });