import AbstractView from "../AbstractView.js";


export default class extends AbstractView {
    constructor(params) {
        super(params);
        this.setTitle("ProductDetail");
    }

    async pageFunction() {
      //this.orderCategory();
    }

    async getHtml() {
        const resCatecory = await fetch("/category");
        const dataCategory = await resCatecory.json(); 

        const resProduct = await fetch("/product");
        const dataProduct = await resProduct.json(); 
        

        const categoryRows = dataCategory.map(category => {
            return `
                <li class="list-group-item"><a href="/products/${category.slug}" data-link>${category.title}</a></li>
            `;
          }).join("");

          const productRows = dataProduct.map(product => {
            return `
              <div class="col-xs-12 col-md-4 p">
                <a class="pa" href="/products/${product.category}/${product.slug}">
                  <img class="pimage" src="${product.image}" alt="">
                </a>
                <h3>${product.title}</h3>
                <h4>${product.price}원</h4> 
                <a class="vd" href="/products/${product.category}/${product.slug}">View Details</a>
              </div>
            `;
          }).join("");

        return `
        <div class="row">
          zzz
          </div>
        
            <br><br><br>
            <hr>    
            <p class="text-center">&COPY; 6조 자바스크립트</p>
        `;
    } 
}