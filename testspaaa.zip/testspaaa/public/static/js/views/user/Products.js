import AbstractView from "../AbstractView.js";


export default class extends AbstractView {
    constructor(params) {
        super(params);
        this.setTitle("Products");
    }

    async pageFunction() {
      return;
    }

    async getHtml() {
        const resCatecory = await fetch("/category");
        const dataCategory = await resCatecory.json(); 

        const resProduct = await fetch("/product");
        const dataProduct = await resProduct.json(); 
        

        const categoryRows = dataCategory.map(category => {
            return `
                <li class="list-group-item"><a href="/products/${category.slug}" data-link>${category.title}</a></li>
            `;
          }).join("");

          const productRows = dataProduct.map(product => {
            return `
              <div class="col-xs-12 col-md-4 p">
                <a class="pa" href="/products/${product.category}/${product.slug}" data-link>
                  <img class="pimage" src="${product.image}" alt=""  href="/products/${product.category}/${product.slug}" data-link>
                </a>
                <h3>${product.title}</h3>
                <h4>${product.price}원</h4> 
                <a class="vd" href="/products/${product.category}/${product.slug}" data-link>View Details</a>
              </div>
            `;
          }).join("");

        return `
        <div class="row">
          <div class="col-xs-12 col-md-3">
            <h3>Categories</h3>
            <ul class="list-group">
              <li class="list-group-item"><a href="/products" data-link>All products</a></li>
                ${categoryRows}
            </ul>
          </div>
          <div class="col-xs-12 col-md-1"></div>
            <div class="col-xs-12 col-md-8">
              <div class="row products">
                ${productRows}
              </div> 
            </div>
          </div>
        
            <br><br><br>
            <hr>    
            <p class="text-center">&COPY; 6조 자바스크립트</p>
        `;
    }
}