import AbstractView from "../AbstractView.js";

export default class extends AbstractView {
    constructor(params) {
        super(params);
        this.setTitle("UserHome");
    }

    async pageFunction() {
      //this.orderCategory();
    }

    async getHtml() {
        const resCatecory = await fetch("/category");
        const dataCategory = await resCatecory.json(); 
        
        const categoryRows = dataCategory.map(category => {
            return `
                <li class="list-group-item"><a href="/products/${category.slug}" data-link>${category.title}</a></li>
            `;
          }).join("");

        return `
        <div class="row">
          <div class="col-xs-12 col-md-3">
            <h3>Categories</h3>
            <ul class="list-group">
              <li class="list-group-item"><a href="/products" data-link>All products</a></li>
                ${categoryRows}
            </ul>
          </div>
          <div class="col-xs-12 col-md-1"></div>
          <div class="col-xs-12 col-md-8">
          <h1>Welcome!</h1>
          <p>
            유저 테스트 페이지입니다.
            <br>
            <br>"/products/:category/:id" 인자 두개 받는 경우 view 매칭이 안되고 있음
            <br>데이터 입력 검증 구현해야 함
            <br>slug 자동 생성 구현해야 함
            <br>base64 인코딩 동기화해야 함
            <br>css 조정해야 함
          </p>
          <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
          </p>
          <p>
              <a href="/about" data-link>View recent posts</a>.
          </p>

          </div>
          </div>
      
        
            <br><br><br>
            <hr>    
            <p class="text-center">&COPY; 6조 자바스크립트</p>
        `;
    }

    orderCategory() {
        const $confirmDeletion = document.querySelectorAll('.confirmDeletion');
        $confirmDeletion.forEach(element => {
              element.addEventListener("click", async (e) => {
              const checkDelete = confirm("삭제하시겠습니까?");
              if (checkDelete) {
                  const pageId = e.target.href.replace("http://localhost:3003/admin/pages/delete-page/", "");
                  const response = await fetch('/page/' + pageId, {
                  method: 'DELETE',
                      headers: {
                        'Content-Type': 'application/json'
                       }
                    });
            
                    // 응답 처리
                    if (response.ok) {
                      console.log('Data submitted successfully');
            
                    } else {
                      console.error('Error submitting data');
                    }
              }
          });
        });
      }
}