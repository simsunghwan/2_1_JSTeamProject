import AbstractView from "../AbstractView.js";

export default class extends AbstractView {
  constructor(params) {
    super(params);
    this.setTitle("AdminProducts/EditProduct");
    this.base64Data = "";
  }

  async pageFunction() {
    this.convertImage();
    this.editProduct();
  }

  async getHtml() {
    const resCatecory = await fetch("/category");
    const dataCategory = await resCatecory.json(); 

    const resProduct = await fetch("/product");
    const dataProduct = await resProduct.json(); 

    const productId = location.pathname.replace("/admin/products/edit-product/", "");

    let title = "";
    let slug = "";
    let desc = "";
    let price = "";
    let image = "";

    let curImage = "";

    const selection = dataCategory.map(category => {
      return `
        <option value="${category.slug}">${category.title}</option>
      `;
    }).join("");

    dataProduct.forEach(product => {
      if (product.id === parseInt(productId)) {
          title = product.title;
          slug = product.slug;
          desc = product.desc;
          price = product.price;
          image = product.image;
      }
    });

    if (image === '') {
      curImage = `<img id="curImage" src="/images/noimage.png" width=100 height=100 alt="">`
    }
    else {
      curImage = `<img id="curImage" src="${image}" width=100 height=100 alt="">`
    }

    return `
      <h2 class="page-title">Add a product</h2>
      <a href="/admin/products" class="btn btn-primary" data-link>Back to all products</a>

      <br><br><br>

      <form id="edit-product-form" method="post">
        <div class="form-group">
          <label for="">Title</label>
          <input type="text" class="form-control" name="title" value="${title}" placeholder="Title">
        </div>

        <div class="form-group">
        <label for="">Slug</label>
        <input type="text" class="form-control" name="slug" value="${slug}" placeholder="Slug">
      </div>

        <div class="form-group">
          <label for="">Desciption</label>
          <textarea name="desc" class="form-control" cols="30" rows="10" placeholder="Description">${desc}</textarea>
        </div>

        <div class="form-group">
          <label for="">Category</label>
          <select name="category" class="form-control">
            ${selection}
          </select>
        </div>  

        <div class="form-group">
          <label for="">Price</label>
          <input type="text" class="form-control" name="price" value="${price}" placeholder="Price">
        </div>

        <div class="form-group">
          <label for="">Current Image</label>
          <p>
            ${curImage}
          </p>
        </div>
 
        <div class="form-group">
          <label for="">Upload Image</label>
          <input type="file" class="form-control" name="image" id="img">
          <img src="#" id="imgPreview" alt="">
        </div>

        <!-- <input type="hidden" name="pimage" value="$image here"> -->
        <button class="btn btn-default" data-href="/admin/products">Submit</button>
      </form>

      <!-- 다중 이미지 삽입은 일단 스킵 -->
    `;
  }

  editProduct() {
    const selectedFile = document.getElementById("img").files[0];
    const productId = location.pathname.replace("/admin/products/edit-product/", "");
    const form = document.getElementById('edit-product-form');
    const self = this;

    form.addEventListener('submit', async (e) => {
      e.preventDefault(); // 기본 제출 동작 방지

      // 이미지 새로 바꾸지 않으면 현재 이미지 저장 구현해야 함

      const formData = new FormData(form);

      console.log(JSON.stringify({
        title: formData.get('title'),
        slug: formData.get('slug'),
        desc: formData.get('desc'),
        category: formData.get('category'),
        price: formData.get('price'),
        image: this.base64Data
      }));

      if (selectedFile === undefined) {
        self.base64Data = document.getElementById('curImage').src;
      }
     
        await fetch('/product/' + productId, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify( {
            title: formData.get('title'),
            slug: formData.get('slug'),
            desc: formData.get('desc'),
            category: formData.get('category'),
            price: formData.get('price'),
            image: this.base64Data 
          })
        });
    });
  }

  convertImage() {
    const inputImage = document.getElementById('img');
    const preview = document.getElementById('imgPreview');
    const self = this;

    inputImage.addEventListener('input', (e) => {
        const selectedFile = document.getElementById("img").files[0];
 
        const dotIndex = selectedFile.name.lastIndexOf('.');
        const fileExt = selectedFile.name.substring(dotIndex, selectedFile.name.length).toLowerCase();

        const imageExt = ['.jpg', '.jpeg', '.png', '.webp'];

        imageExt.forEach(ext => {
          if (ext === fileExt) {
            let reader = new FileReader();

            reader.onload = function(e) {
              preview.setAttribute('src', e.target.result);
              preview.setAttribute('width', 100);
              preview.setAttribute('height', 100); 
     
              self.base64Data = e.target.result;
             }
     
           reader.readAsDataURL(selectedFile);
          }
        }) 
    }); 
  }
}




