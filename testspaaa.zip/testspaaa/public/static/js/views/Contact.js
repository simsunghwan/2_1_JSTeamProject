import AbstractView from "./AbstractView.js";

export default class extends AbstractView {
    constructor(params) {
        super(params);
        this.setTitle("Contact");
    }

    async pageFunction() {
        return;
    }

    async getHtml() {
        return `
            <h1>조원 소개</h1>
            <p>조원 소개 페이지입니다.</p>
        `;
    }
}